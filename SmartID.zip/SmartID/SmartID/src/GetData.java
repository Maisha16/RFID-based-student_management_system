


public class GetData {
    public static  String getUid;


    public static void setuid(String str)
    {
        getUid=str;
    }

    public  static  String getuid()
    {
        return  getUid;
    }


}
